"""AVS Migration Analytics — application assembly.

This module is imported by the root-level ``Home.py`` entry point, which is what
``streamlit run`` executes.  Keeping the entry at the repo root ensures the
``app`` package is importable and avoids Streamlit's automatic ``pages/``
discovery (our report views live in ``app/views`` and are wired up explicitly
via ``st.navigation``).
"""
from __future__ import annotations

import pandas as pd
import streamlit as st


_BOOT_LOGGED = False


def run() -> None:
    # set_page_config must be the first Streamlit command executed.
    st.set_page_config(page_title="AVS Migration Analytics", page_icon="📈",
                       layout="wide", initial_sidebar_state="expanded")

    from app import state
    from app.config import APP_NAME, APP_TAGLINE
    from app.version import build_stamp, version_line
    from app.ui.theme import inject_css
    from app.views import (category_dashboard, column_mapping, data_inconsistency,
                           data_upload, debug, eos_programme, insights_page,
                           methodology, overview, reports, trend_analysis)

    global _BOOT_LOGGED
    if not _BOOT_LOGGED:                    # once per server start, into the console
        print(f"AVS Migration Analytics — {version_line()}", flush=True)
        _BOOT_LOGGED = True

    inject_css()
    ctx = state.ensure_context()
    _sidebar_brand(ctx, state, APP_NAME, APP_TAGLINE)

    # url_path must be explicit & unique because every view's callable is `render`.
    nav = st.navigation({
        "Executive": [
            st.Page(overview.render, title="Overview", icon=":material/dashboard:",
                    url_path="overview", default=True),
            st.Page(insights_page.render, title="Insights",
                    icon=":material/lightbulb:", url_path="insights"),
        ],
        # One page per migration category, listed broadest first: All AVS, then
        # the EOS family, then the motion leaving AVS.
        "Status Report": [
            st.Page(category_dashboard.all_avs, title="All AVS Migrations",
                    icon=":material/cloud:", url_path="all-avs"),
            st.Page(category_dashboard.eos_all, title="EOS Migrations (All)",
                    icon=":material/dns:", url_path="eos-all"),
            st.Page(category_dashboard.eos_gen1, title="EOS Migration — Gen-1",
                    icon=":material/memory:", url_path="eos-gen1"),
            st.Page(category_dashboard.eos_gen2, title="EOS Migration — Gen-2",
                    icon=":material/developer_board:", url_path="eos-gen2"),
            # The tracking sheet on its own terms — includes accounts the FDO
            # export does not hold yet, which no page above can show.
            st.Page(eos_programme.render, title="EOS Programme Tracker",
                    icon=":material/fact_check:", url_path="eos-programme"),
            st.Page(category_dashboard.avs_native, title="AVS → Azure Native",
                    icon=":material/cloud_sync:", url_path="avs-native"),
        ],
        # One page per measure, every migration category on it — the inverse of
        # the category dashboards, which no longer carry a trends section.
        "Trend Analysis": [
            st.Page(trend_analysis.nominations, title="Nomination Trends",
                    icon=":material/timeline:", url_path="nomination-trends"),
            st.Page(trend_analysis.acr, title="ACR Trend",
                    icon=":material/payments:", url_path="acr-trend"),
            st.Page(trend_analysis.nodes, title="Nodes Deployed",
                    icon=":material/dns:", url_path="nodes-deployed"),
            st.Page(trend_analysis.cores, title="Cores Migrated",
                    icon=":material/memory:", url_path="cores-migrated"),
            st.Page(trend_analysis.completed, title="Migrations Completed",
                    icon=":material/task_alt:", url_path="migrations-completed"),
        ],
        "Data": [
            st.Page(reports.render, title="Reports & Export",
                    icon=":material/picture_as_pdf:", url_path="reports"),
            st.Page(data_inconsistency.render, title="Data Inconsistency",
                    icon=":material/rule:", url_path="data-inconsistency"),
            st.Page(data_upload.render, title="Data & Upload", icon=":material/upload_file:",
                    url_path="data-upload"),
            st.Page(column_mapping.render, title="Column Mapping",
                    icon=":material/table_chart:", url_path="column-mapping"),
            st.Page(debug.render, title="Debug", icon=":material/bug_report:",
                    url_path="debug"),
        ],
        "Reference": [
            st.Page(methodology.render, title="Methodology & Logic",
                    icon=":material/menu_book:", url_path="methodology"),
        ],
    })

    nav.run()
    st.sidebar.divider()
    built, fingerprint = build_stamp()
    st.sidebar.caption(f"**Build {built}** · `{fingerprint}`  \n"
                       f"{version_line().split(' · ')[0]} · Runs locally · No data "
                       f"leaves this machine")


def _sidebar_brand(ctx, state, app_name: str, tagline: str) -> None:
    st.sidebar.markdown(
        f"<div style='padding:6px 0 2px 0'>"
        f"<div style='font-size:1.25rem;font-weight:800;color:#0A4C86'>📈 {app_name}</div>"
        f"<div style='font-size:.78rem;color:#5C6470'>{tagline}</div></div>",
        unsafe_allow_html=True)
    st.sidebar.divider()

    src = "Sample dataset" if ctx.is_sample else ctx.filename
    if ctx.is_sample:
        # Uploads live only as long as the browser session: a refresh or a
        # restart silently puts the sample back, and every report then reads it.
        st.sidebar.warning("Showing the bundled **sample** data, not your file. "
                           "Upload again on **Data & Upload**.")
    n_cust = len(ctx.customer)
    lines = [f"**FDO Dataset:** {src}",
             f"**Waves:** {len(ctx.fact):,} · **Accounts:** {n_cust:,}"]
    if ctx.has_tracker:
        # Which document is answering for the EOS generations and dates is the
        # kind of thing a reader should never have to go and check.
        matched = (ctx.report.get("tracker") or {}).get("matched_accounts", 0)
        lines.append(f"**EOS tracking sheet:** {ctx.tracker_filename} "
                     f"({matched:,} matched)")
    st.sidebar.markdown("  \n".join(lines))
    cur = pd.Timestamp(ctx.as_of).date()
    new_asof = st.sidebar.date_input("Reporting as-of date", value=cur,
                                     min_value=pd.Timestamp("2000-01-01").date(),
                                     max_value=pd.Timestamp("2100-12-31").date(),
                                     help="Anchors all date-range presets and the "
                                          "This-Week/Month/Quarter/YTD windows. "
                                          "Defaults to today; change it to report as "
                                          "of an earlier date.")
    if pd.Timestamp(new_asof) != pd.Timestamp(ctx.as_of):
        state.reload_with(as_of=pd.Timestamp(new_asof))
        st.rerun()

    from app.ui import components
    components.global_date_controls(ctx)

    st.sidebar.radio(
        "Counting mode", [state.MODE_CUSTOMER, state.MODE_WAVE], key=state.MODE_KEY,
        help="Customer mode deduplicates waves: each customer counts once, with the "
             "approval date from Wave-1 and status from the last wave. Wave-level counts "
             "every nomination row.")
    st.sidebar.divider()
