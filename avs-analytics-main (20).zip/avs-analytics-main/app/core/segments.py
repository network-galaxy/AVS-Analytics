"""Migration categories, platform classification and Gen-1/Gen-2 generations.

Three orthogonal classifications drive every dashboard:

* **Migration category** — which report a nomination belongs to.  Derived from the
  migration path and offering: what platform it is coming *from* and going *to*.
  A path containing "(From AVS)" targets Azure-native services; everything else
  whose target is AVS (on-premises, VMG, AWS/VMC, AVS-to-AVS, EOS refresh) is an
  AVS migration.
* **EOS population** — an account is an EOS Migration account when ANY of its
  waves carries an "AVS Migration - Gen1" or "AVS Migration - Gen2" tag; that tag
  also fixes its generation.  With no generation tag on any wave, the offering
  falls back to deciding it: a migration path (or offering) reading
  "AV36/AV36P/AV52 - EOS" puts the account in scope with no generation.  There is
  one dataset: nothing here depends on a second worksheet.
* **Generation** — Gen-1 / Gen-2 / Unclassified, decided per **TPID** from the Tags
  of *all* its waves (host SKUs as a fallback) — never per wave, never by name.

Every rule here is TPID-first: account names differ between worksheets and source
systems, so they are never used for matching.
"""
from __future__ import annotations

import re

import pandas as pd

# --------------------------------------------------------------------------- #
# Migration categories
# --------------------------------------------------------------------------- #
CAT_EOS_ALL = "eos_all"
CAT_EOS_GEN1 = "eos_gen1"
CAT_EOS_GEN2 = "eos_gen2"
CAT_EOS_UNCLASSIFIED = "eos_unclassified"
CAT_ALL_AVS = "all_avs"
CAT_AVS_NATIVE = "avs_native"

#: The categories that get a page and a report of their own.
CATEGORY_LABELS = {
    CAT_EOS_ALL: "EOS Migration",
    CAT_EOS_GEN1: "EOS Migration — Gen-1",
    CAT_EOS_GEN2: "EOS Migration — Gen-2",
    CAT_ALL_AVS: "All AVS Migrations",
    CAT_AVS_NATIVE: "AVS → Azure Native",
}

#: EOS accounts in scope through their migration path with no generation tag.
#: They are *inside* CAT_EOS_ALL and counted there; they no longer get a report
#: of their own, because the Data Inconsistency page is where that disagreement
#: belongs.  ``population(fact, CAT_EOS_UNCLASSIFIED)`` still selects them, and
#: this is the label a drill-down row carries.
UNCLASSIFIED_LABEL = "EOS Migration — No generation tag"

# --------------------------------------------------------------------------- #
# Platforms
# --------------------------------------------------------------------------- #
PLATFORM_AVS = "AVS"
PLATFORM_AZURE_NATIVE = "Azure Native"
PLATFORM_ONPREM = "On-Premises"
PLATFORM_VMG = "VMG"
PLATFORM_AWS = "AWS / VMC"
PLATFORM_OTHER = "Other"


def source_platform(*values) -> str:
    """Platform a nomination is migrating *from*."""
    text = " ".join(str(v) for v in values if v is not None).lower()
    if "from avs" in text or "avs to avs" in text:
        return PLATFORM_AVS
    if "vmg" in text:
        return PLATFORM_VMG
    if "aws" in text or "vmc" in text:
        return PLATFORM_AWS
    if "onprem" in text or "on prem" in text or "on-prem" in text or "on premises" in text:
        return PLATFORM_ONPREM
    if _has_eos_marker(text):
        return PLATFORM_AVS          # an EOS refresh moves off ageing AVS hosts
    return PLATFORM_OTHER


def target_platform(*values) -> str:
    """Platform a nomination is migrating *to* — the category driver."""
    text = " ".join(str(v) for v in values if v is not None).lower()
    if "from avs" in text:
        return PLATFORM_AZURE_NATIVE
    if "to avs" in text or "avs migration" in text or _has_eos_marker(text):
        return PLATFORM_AVS
    if "odaa" in text or "oracle" in text:
        return PLATFORM_AZURE_NATIVE
    if "avs" in text:
        return PLATFORM_AVS
    return PLATFORM_OTHER


def _has_eos_marker(text: str) -> bool:
    from .cleaning import is_av36_eos_path      # imported lazily: cleaning imports this module
    return is_av36_eos_path(text)


# --------------------------------------------------------------------------- #
# Generation (Gen-1 / Gen-2 / Unclassified) — decided per TPID, across all waves
# --------------------------------------------------------------------------- #
GEN_1 = "Gen-1"
GEN_2 = "Gen-2"
GEN_UNCLASSIFIED = "Unclassified"

# Host SKUs no longer classify anything (the Tags column does) — the codes are
# still parsed so the SKU a wave used can be shown in drill-downs.
_SKU_TOKEN_RE = re.compile(r"av\s*(36p|36|48|52|64)", re.I)

# The Tags column is the authoritative generation signal.  Several tags are
# concatenated into one cell with no separator — "Qualify and AccelerateAVS
# Migration - Gen1", "InternalAVS Migration - Gen2", "Qualify and AccelerateFCS
# On Hold Reach OutAVS Migration - Gen1" — so the marker is matched against the
# cell stripped of everything but letters and digits.  That way spacing, dashes
# (hyphen or en dash) and neighbouring tags cannot hide it.
_GEN_TAG_MARKERS = ((GEN_1, "avsmigrationgen1"), (GEN_2, "avsmigrationgen2"))


def _compact(value) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def generation_from_tags(tag_values) -> str | None:
    """Generation from the Tags column, or None when no generation tag is present.

    Gen-1 wins when a TPID carries both markers across its waves, matching the
    SKU precedence.
    """
    found = set()
    for value in tag_values:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            continue
        compact = _compact(value)
        for gen, marker in _GEN_TAG_MARKERS:
            if marker in compact:
                found.add(gen)
    for gen, _marker in _GEN_TAG_MARKERS:
        if gen in found:
            return gen
    return None


def sku_codes(value) -> set[str]:
    """Normalised SKU codes found in a raw SKU cell ("AV36P Node" -> {'av36p'})."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return set()
    return {"av" + m.group(1).lower() for m in _SKU_TOKEN_RE.finditer(str(value))}


def classify_generation(tag_values) -> str:
    """Gen-1 / Gen-2 / Unclassified for one TPID, from the Tags of all its waves.

    A single wave tagged "AVS Migration - Gen1" makes the whole account Gen-1;
    "AVS Migration - Gen2" makes it Gen-2.  Gen-1 wins when both appear across
    the account's waves.  No generation tag anywhere -> Unclassified, which also
    means the account is not an EOS Migration account (see ``eos_population``).
    """
    return generation_from_tags(tag_values) or GEN_UNCLASSIFIED


def generation_by_tpid(fact: pd.DataFrame) -> pd.Series:
    """Map of TPID -> generation, evaluating the Tags of every wave it owns."""
    if fact.empty:
        return pd.Series(dtype="object")
    tags = fact["tags"] if "tags" in fact.columns else pd.Series("", index=fact.index)
    df = fact.assign(_key=tpid_key(fact), _tags=tags)
    return df.groupby("_key")["_tags"].apply(lambda s: classify_generation(s.tolist()))


def tpid_key(fact: pd.DataFrame) -> pd.Series:
    """The authoritative grouping key: TPID, falling back to the account name.

    TPID is the identifier for every join, lookup and deduplication.  The name is
    used only when a row carries no TPID at all, so those rows still roll up to
    something rather than collapsing together.
    """
    tpid = fact["tpid"].astype("string").str.strip()
    tpid = tpid.replace({"": pd.NA, "nan": pd.NA, "0": pd.NA})
    name = fact["customer_name"].astype("string").str.strip().str.upper()
    return tpid.fillna("NAME:" + name.fillna("UNKNOWN"))


# --------------------------------------------------------------------------- #
# EOS population
# --------------------------------------------------------------------------- #
def eos_population(fact: pd.DataFrame) -> pd.Series:
    """Per-row membership of the EOS Migration population, decided per account.

    1. **Tag** — ANY wave carrying "AVS Migration - Gen1" or "AVS Migration - Gen2"
       brings the whole account in, with that generation.
    2. **Fallback** — no generation tag on any wave, but an EOS offering
       ("AV36/AV36P/AV52 - EOS" on the migration path, factory offering or linked
       offering): the account is still in scope, with no generation.

    Either way membership is per TPID, never per row: one qualifying wave brings
    every wave of that account with it.
    """
    if fact.empty:
        return pd.Series(dtype=bool)
    if "generation" in fact.columns:
        tagged = fact["generation"].isin((GEN_1, GEN_2))
    else:
        tagged = tpid_key(fact).map(generation_by_tpid(fact)).isin((GEN_1, GEN_2))
    keys = fact["tpid_key"] if "tpid_key" in fact.columns else tpid_key(fact)
    marker = fact["is_av36_eos"].astype(bool).groupby(keys).transform("any")
    # A "(From AVS)" wave is leaving AVS, not refreshing ageing AVS hosts, so it
    # is never EOS — whatever tag it happens to carry.  See ``population``.
    return (tagged | marker) & ~fact["is_from_avs"].astype(bool)


# --------------------------------------------------------------------------- #
# Category populations
# --------------------------------------------------------------------------- #
def population(fact: pd.DataFrame, category: str) -> pd.DataFrame:
    """Rows belonging to a reporting category.

    **The AVS → Azure Native motion is reported on its own and nowhere else.**
    It moves workloads *off* AVS onto Azure-native services, so counting it under
    All AVS Migrations (which is onboarding *to* AVS) or under EOS Migration
    (which is refreshing ageing AVS hosts) would double-count it into the wrong
    story.  Every category below therefore excludes ``is_from_avs``, and
    ``avs_native`` selects exactly those rows.

    ``all_avs`` is every remaining nomination whose **target** platform is AVS,
    whatever the source; the EOS categories are the EOS population split by the
    TPID's generation.
    """
    if fact.empty:
        return fact
    if category == CAT_AVS_NATIVE:
        return fact[fact["is_from_avs"].astype(bool)]

    # Everything else is the onboarding-to-AVS side of the house.
    onboarding = fact[~fact["is_from_avs"].astype(bool)]
    if onboarding.empty:
        return onboarding
    if category == CAT_ALL_AVS:
        # Every EOS Migration account is an AVS migration too, even when its own
        # path does not read as AVS-targeting.
        return onboarding[onboarding["is_avs_target"].astype(bool)
                          | onboarding["is_eos_population"].astype(bool)]
    if category == CAT_EOS_GEN1:
        return onboarding[(onboarding["generation"] == GEN_1)
                          & onboarding["is_eos_population"].astype(bool)]
    if category == CAT_EOS_GEN2:
        return onboarding[(onboarding["generation"] == GEN_2)
                          & onboarding["is_eos_population"].astype(bool)]
    if category == CAT_EOS_UNCLASSIFIED:
        # In scope through the offering fallback rather than a tag, so there is no
        # generation to report — kept visible, never folded into Gen-1 or Gen-2.
        return onboarding[onboarding["is_eos_population"].astype(bool)
                          & (onboarding["generation"] == GEN_UNCLASSIFIED)]
    return onboarding[onboarding["is_eos_population"].astype(bool)]


def category_summary(fact: pd.DataFrame) -> pd.DataFrame:
    """TPID counts per category — used to show where the population sits."""
    rows = []
    for cat, label in CATEGORY_LABELS.items():
        pop = population(fact, cat)
        rows.append({"category": label,
                     "tpids": int(tpid_key(pop).nunique()) if not pop.empty else 0,
                     "nominations": int(len(pop))})
    return pd.DataFrame(rows)


def category_label_series(fact: pd.DataFrame) -> pd.Series:
    """A single readable category per row, for drill-down tables and exports.

    A row can legitimately sit in more than one category (an EOS refresh is also
    an AVS migration), so this reports the most specific one: the Azure-native
    motion first, then the EOS generation, then the general AVS population.
    """
    if fact.empty:
        return pd.Series(dtype="object")
    gen_label = {GEN_1: CATEGORY_LABELS[CAT_EOS_GEN1],
                 GEN_2: CATEGORY_LABELS[CAT_EOS_GEN2]}
    out = pd.Series("Other", index=fact.index, dtype="object")
    avs = fact["is_avs_target"].astype(bool)
    out[avs] = CATEGORY_LABELS[CAT_ALL_AVS]
    eos = fact["is_eos_population"].astype(bool)
    out[eos] = fact.loc[eos, "generation"].map(
        lambda g: gen_label.get(g, UNCLASSIFIED_LABEL))
    out[fact["is_from_avs"].astype(bool)] = CATEGORY_LABELS[CAT_AVS_NATIVE]
    return out


# --------------------------------------------------------------------------- #
# Data consistency between the generation tag and the EOS migration path
# --------------------------------------------------------------------------- #
def eos_consistency(fact: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Where the generation tag and the EOS migration path disagree.

    Two ways an export can be inconsistent, both worth seeing before trusting a
    number:

    ``tagged_without_eos_path``
        Accounts carrying an "AVS Migration - Gen1/Gen2" tag whose waves never
        show an EOS migration path — in scope by tag alone.
    ``eos_path_without_tag``
        Waves on an EOS migration path belonging to accounts with no generation
        tag anywhere — in scope by path alone, so no generation can be reported.
    """
    empty = pd.DataFrame(columns=["tpid", "customer_name", "phase",
                                  "migration_path", "tags", "generation"])
    if fact.empty:
        return {"tagged_without_eos_path": empty, "eos_path_without_tag": empty}

    keys = fact["tpid_key"] if "tpid_key" in fact.columns else tpid_key(fact)
    tagged = fact["generation"].isin((GEN_1, GEN_2))
    account_has_eos_path = fact["is_av36_eos"].astype(bool).groupby(keys).transform("any")

    cols = [c for c in ("tpid", "customer_name", "phase", "migration_path",
                        "factory_offering", "tags", "generation") if c in fact.columns]

    # One row per account for the tag-side mismatch; wave-level for the path side,
    # since a single untagged wave on an EOS path is what you want to look at.
    tagged_no_path = fact[tagged & ~account_has_eos_path]
    if not tagged_no_path.empty:
        tagged_no_path = tagged_no_path.groupby(keys[tagged & ~account_has_eos_path],
                                                as_index=False).first()
    path_no_tag = fact[~tagged & fact["is_av36_eos"].astype(bool)]

    return {
        "tagged_without_eos_path": tagged_no_path[cols] if not tagged_no_path.empty else empty,
        "eos_path_without_tag": path_no_tag[cols] if not path_no_tag.empty else empty,
    }
