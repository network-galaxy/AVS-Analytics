# 📈 AVS Migration Analytics

**A professional, 100% local executive dashboard for Azure VMware Solution (AVS) migration analytics and reporting.**

Upload your **FDO Dataset** — the AVS nominations export, one file or several that make
up one dataset (CSV / XLSX / XLS) — and, optionally, the **manual EOS tracking sheet**
alongside it, and instantly get executive dashboards, trend analysis, a deterministic
insights engine, and one‑click exports — a leadership PDF and a single interactive HTML
file you can email, carrying the same sections — all running entirely on your own
machine.

![Overview](docs/screenshots/01_overview.png)

---

## 🔒 Privacy & Offline Guarantee (read this first)

This application is **standalone and self‑sufficient. It does not talk to the internet.**

- ❌ **No external APIs** — no REST/cloud backend, no third‑party services.
- ❌ **No AI / no LLM** — the insights engine is 100% deterministic rules.
- ❌ **No telemetry, no tracking, no outbound calls** of any kind.
- ✅ **All processing is local** — your data never leaves the machine.
- ✅ The only "server" is a **local web server bound to `127.0.0.1`** (loopback) that draws
  the dashboard in your browser (this is how every browser app works). It is **not reachable
  from your network or the internet** and exchanges data only between your browser and
  your own computer.

The only time an internet connection is used is **once, when you install the Python
libraries** (`pip install`). After that, the app runs fully offline / air‑gapped.

> Want to verify? There isn't a single `requests`, `urllib`, `httpx`, `socket`, cloud SDK
> or AI client anywhere in the code. The only third‑party libraries are `streamlit`,
> `pandas`, `numpy`, `duckdb`, `plotly`, `reportlab` and `matplotlib` — all local compute,
> **no bundled browser/Chromium** and no compiled launcher.

---

## 🚀 Quick Start (Windows)

Install Python once, then run **one command** whenever you want the app. There are **no
`.bat`/`.exe` launchers and no scripts** — which keeps it friendly to strict corporate
antivirus/EDR.

**1. Install Python 3.11 (one time).** Download it from
[python.org](https://www.python.org/downloads/windows/); on the first installer screen tick
**“Add python.exe to PATH”**, then click **Install Now** (no admin rights needed).

**2. Set up the app (one time).** Open **Command Prompt**, `cd` into the project folder, and run:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

**3. Run the app (every time).** From the same folder:

```bat
.venv\Scripts\python.exe -m streamlit run Home.py
```

**4. Open your browser** at **http://127.0.0.1:8501**
(use `http://` and `127.0.0.1` — **not** `https`, **not** `localhost`).

Keep the terminal window open while using the app; close it or press **Ctrl+C** to stop.
No activation step, no admin, no registry changes. Full walk‑through with proxy tips and
troubleshooting: **[`docs/INSTALL.md`](docs/INSTALL.md)**.

---

## 📊 The Reports

| # | Report | What it shows |
|---|--------|---------------|
| 🏠 | **Overview** | Portfolio KPIs, status & regional distribution, delivery health, top insights |
| 1 | **Status Report → All AVS Migrations** | Headline metrics, current pipeline, **top 10 accounts by ACR**, regional breakdown, detailed data — one row per account |
| 2 | **Status Report → EOS Migrations (All / Gen‑1 / Gen‑2)** | The same report for the EOS family; Gen‑1 and Gen‑2 are subsets of All |
| 3 | **Status Report → AVS → Azure Native** | The same report for the "(From AVS)" motion, plus **top 10 accounts by ACR** and **By offering & target** |
| 4 | **Trend Analysis → Nomination Trends** | Unique TPIDs nominated per month, in every migration category |
| 5 | **Trend Analysis → ACR Trend** | ACR claimed per month, by each wave's Actual End Date, in every category — plus the **top 10 accounts by ACR** on the two broad motions |
| 6 | **Trend Analysis → Nodes Deployed** | Total Cores completed per month, across the AVS motions |
| 7 | **Trend Analysis → Cores Migrated** | The same measure for AVS → Azure Native, under the noun that motion uses |
| 8 | **Trend Analysis → Migrations Completed** | Unique TPIDs whose latest wave completed, per month, in every category |
| 💡 | **Insights** | Full deterministic insights engine, grouped by category |
| 📄 | **Reports & Export** | One report, two formats carrying **the same sections in the same order**: a two‑part management **PDF** (the executive reports plus the account records, with contents, bookmarks and cross‑links) and a single self‑contained **interactive HTML** file to email; CSV exports |
| 📖 | **Methodology & Logic** | Plain‑language reference for every metric, status, scope and insight rule |

Every report has **Region / Status / path filters** and a **date‑range preset**
(This/Last week, This/Last month, Last 3/6 months, This FY, All time, Custom — default
**All time**, so every report opens on the whole dataset), plus an adjustable **"as‑of" date** that anchors the presets and all
This‑Week/Month/Quarter/YTD windows.

### Reporting floor (FY25 onwards)

The dashboard reports from **FY25** (1 Jul 2024) onwards. Waves nominated earlier are
dropped **as the file is read** — before the customer rollup and before the SQL tables
are registered — so no chart, table, total, insight, CSV or PDF can include them, and
**"All time" means FY25 onwards** everywhere. A wave belongs to the fiscal year of its
nomination date (approval date, else creation date); a wave carrying neither cannot be
shown to be out of scope, so it stays. Every page reports how much was excluded.
Configurable via `AVS_REPORTING_FLOOR_FY`.

### Reporting scope (AVS‑centric)

The dashboard's primary focus is **AVS Migration Nominations** (onboarding *to* AVS).
Offerings whose migration path is **"(From AVS)"** — i.e. migrating *away* from AVS to an
Azure‑native service — are a different motion and are **reported on their own**
(*Status Report → AVS → Azure Native*, and its own section of
each Trend Analysis page). They never get mixed into another category's numbers, so the
primary figures stay clean. **Region** is shown as geography only
(Americas / EMEA / ASIA); the segment lives in **Customer Segment**.

---

## 🧠 Insights Engine (deterministic — no AI)

Rules derived directly from the data, including:

- Highest / lowest approval‑rate region
- Fastest‑closing region & overall closure rate
- Approval velocity (median created→approved latency, slowest region)
- Oldest open nomination
- Most common migration status
- Fastest‑growing migration path (period‑over‑period)
- Top Azure‑native destination & completion rate
- EOS risk hotspots
- ACR concentration
- **Data‑quality issues** (contaminated values, dirty regions, invalid segments, bad dates…)

---

## 🔁 Counting modes & wave deduplication

A customer often has **multiple waves** (Wave‑1, Wave‑2 …). Counting every wave would
double‑count the customer, so the app supports two counting modes via a **global toggle**
in the sidebar:

- **Customer (deduplicated)** — *default*. Each customer counts **once**. Following the
  agreed rules:
  - **Category membership = any wave.** A customer is an **AV36 EOS** nomination if *any*
    of its waves has an AV36/EOS migration path; likewise **AVS → Azure Native** if any
    wave is a from‑AVS path.
  - **Approval date = Wave‑1** (the first/lowest‑numbered wave).
  - **Status = last wave.** If the last wave is done/completed the account is **closed**;
    otherwise it takes the last wave's operational/EOS status.
- **Nomination (wave‑level)** — every wave/row counts (raw detail).

This applies across all reports, so headline numbers reflect real accounts rather than
inflated wave counts. The sidebar shows both totals (e.g. *Waves: 1,240 · Accounts: 815*).

## 📄 Reports & Export

The **Reports & Export** page produces the same leadership‑ready report in two formats.
Pick which of the three executive reports to include, whether to attach the drill‑down
detail, and the cover text; both formats then select the same populations through the
same code, so they cannot disagree.

### PDF — to print, file and circulate
A two‑part document: the three executive reports up front, the account records behind
them after, with a cover, contents, bookmarks, page numbers and links both ways. **It
carries the same sections as the interactive report, in the same order** — the headline
tiles over a This‑FY row, the EOS programme matrix, every trend month by month and then
fiscal year against fiscal year, the top 10 accounts by ACR, the pipeline, the regional
cut, the generations and the accounts that have stopped — each chart with its own numbers
tabulated underneath it. Part 2 adds what a printed page cannot open on demand: the
regional matrix, the pipeline counts and the account records. Charts are rendered locally
with **matplotlib** — no bundled browser, no internet.

### Interactive HTML — to email
**One self‑contained file.** The dashboard's own look and feel, with the charts still
interactive (hover, zoom, click a legend to hide a series), the drill‑downs still
accordions, the tables sortable and searchable, and a contents panel that follows you
down the page. Charts, styles and data are all *inside* the file — nothing is fetched —
so it opens from a mail client's download folder on a machine with no network. It prints
cleanly too. Expect a few megabytes: the charting library has to travel with it for any
of that to work offline.

It follows the dashboard where it counts. **Every chart opens the accounts behind it and
clicking the chart filters them; the headline tiles are clickable too**, driving a single
accounts panel beneath the row — a bar on the nominations trend
narrows the accounts to that month, a doughnut slice to that state, a stacked‑bar segment
or heatmap cell to that WW Region *and* stage; clicking again clears. The tiles gain a
**This FY** row whenever the reporting period is something else; money reads `$2M` /
`$840K` on axes as well as tiles; and a **Wide** toggle sets the reading width.

CSV exports of the cleaned data, the insights and the inconsistency review are available
on the same page.

---

## 🗂️ Data & Column Mapping

The app understands the standard AVS nominations export schema out of the box and
**auto‑maps columns** on upload. If your file uses different headers:

- Open **Data & Upload** to load a file and inspect a per‑column fill/quality profile.
- Open **Column Mapping** to map your headers to the analytics fields, then **save the
  mapping** for reuse on future files.

Supported uploads: **CSV, XLSX, XLS**. First row must be headers.

### The manual EOS tracking sheet

The EOS programme keeps its own spreadsheet beside the export, and **Data & Upload** takes
it as a second, separate upload. It is keyed on **TPID and nothing else**: every other
detail an EOS report needs — Factory PM, Solution Architect, region, offering, ACR, waves
— is looked up in the FDO Dataset by that TPID, so the sheet never has to repeat or
contradict them. These columns lead wherever they are filled in:

| Column | What it decides |
|---|---|
| **Target SDDC Generation** (`Gen1` / `Gen2`) | The account's generation — and so its place in the EOS reports. Falls back to the `AVS Migration - Gen1/Gen2` tag. |
| **Migration Status** | **Replaces the export's** for the account: `1. Kick-Off Awaited`, `2. Planning & Prerequisites`, `3. Ready for Migration`, `4. Executing Migration`, `5. Sign-off Pending`, `6. Completed`, `7. On Hold`, `8. Cancelled`. |
| **Current State** | **Replaces the export's** for the account: `On Track`, `Completed`, `Blocked`. |
| **Migration Start Date** | *Migration start* in the programme matrix. Falls back to the derivation from the earliest wave under way. |
| **Actual Migration End Date** | *Migration end* in the programme matrix, and the date of a completed account. Falls back to the latest wave completing. |

The status and state are written onto every wave the export still has open (or the
latest wave when all are closed); a wave the export already shows as completed or
cancelled keeps its own. They decide the account's state — **On-Track**, **Completed**,
**Blocked**, **On Hold**, **Cancelled** — in every report, and the export's originals
stay on the row as `fdo_migration_status` / `fdo_current_state`. The two documents
number their statuses differently (6 is *Cancelled* in one and *Completed* in the other),
so no rule tests a number: each row carries a `status_class` (`app/core/statuses.py`).

`Total SDDCs in Scope for Migration` and `Number of SDDCs Migrated` feed the **EOS
Programme Tracker** page (Status Report → EOS Programme Tracker, and a section after the
EOS report in both exports): accounts by Migration Status and Current State, status ×
state, SDDC progress, starts and completions by month, days in migration, WW Region ×
status and the accounts that need attention. It reads the sheet itself, so an account
the FDO Dataset does not hold yet is still reported there.

The sheet is read forgivingly: a title row above the headers is fine (the header row is
the first with a TPID column), a workbook's sheets are tried until one has a TPID column,
TPIDs match as plain digits (`12,039,532`, `12039532.0` and `12039532` are one), and a
month written alone (`Feb-26`) is the 1st of that month. Data & Upload shows which column
fed each field, every date as written beside the date it was read as, any value it could
not read, and lets you say whether ambiguous dates (`03-02-2026`) are day- or month-first.

Every account carries where its generation came from, and the page reports what the sheet
reached and what it did not: a TPID the FDO Dataset has never heard of has no nomination
behind it, so it is **named** under Data Inconsistency rather than invented — and when
*none* of the sheet's TPIDs match, an empty EOS report says so. With no sheet loaded,
every EOS figure is what it was before the sheet existed.

### When a report looks wrong: Data → Debug

**Debug** shows, for the data loaded right now, what was read and what every rule made of
it: whether it is your file or the bundled sample (uploads last only for the browser
session), the EOS funnel from "in the file" to "in the report", each key column with its
dates as written beside how they were read, the tracking sheet's columns and the TPIDs on
each side of the join, and — for any TPID you type — every decision taken on that account
and why. The whole diagnosis is one text block with a copy button, sized to photograph.

### Several files, one dataset

The source system exports per offering, so AVS nominations and the "(From AVS)"
Azure‑native ones often arrive as separate files. Select them **all at once** on
**Data & Upload**: they are stacked into a single dataset before anything else
happens, so the mapping, cleaning, rollup and every report see one portfolio.

- Headers are matched **case‑ and whitespace‑insensitively** (`tpid ` = `TPID`),
  keeping the spelling from the file that introduced each column.
- A column one file does not have is **blank** for that file's rows.
- Every row keeps a **Source File** value, and the page reports what each file
  contributed after cleaning.

If an upload fails, the page shows the whole diagnosis — the file, the ingest stage,
the error, a plain‑English likely cause, the line of code that raised it, which
columns are empty, which fields are unmapped, and the full traceback. Nothing is
loaded on a failure: the dataset you already had is untouched.

### What the app derives from your data
- **WW Region** — the source `WW Region` value, cleaned of numeric prefixes; every
  grouping, filter and chart reports on it under that name.
- **Migration direction** — *Onboard to AVS* vs *AVS → Azure Native* (from the migration path).
- **Azure‑native target** — e.g. *SQL Server MI Migration (From AVS)* → *Azure SQL Managed Instance*.
- **EOS / operational status** — unified from Current State + Milestone Status + Migration
  Status code + planned‑end vs as‑of date.
- **Approval / closure / aging** flags and cycle times.
- **Cleaned values** — currency (incl. Indian "1,92,000" grouping), dates (MM‑DD‑YYYY),
  region normalization (strips numeric prefixes like "1800 Americas - Enterprise").

---

## ⚙️ Architecture

```
Browser (localhost:8501)
        │  (local only)
        ▼
Streamlit UI  ──►  app/views/*   (13 report pages, st.navigation)
        │
        ▼
app/core/   loader → cleaning → DuckDB fact table
            ├─ analytics  (DuckDB SQL aggregations, filters, trends, Sankey)
            ├─ metrics    (WTD/MTD/QTD/YTD, KPIs)
            ├─ insights   (deterministic rules)
            ├─ exporter   (ReportLab PDF + local chart images)
            └─ html_report(single-file interactive HTML, inlined Plotly)
```

- **DuckDB** runs all aggregations in‑process for speed at the 500k‑row / 100‑column target.
- **Caching** (`st.cache_data` / `st.cache_resource`) keeps page switches instant.
- Pure‑Python, single runtime — easy to package and maintain.

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for details.

---

## 🏢 Corporate / locked‑down laptops

This app is deliberately easy on antivirus/EDR policies:

- **No compiled executables and no launcher scripts** (`.bat`/`.ps1`) — you run plain
  Python source (`streamlit run Home.py`).
- **No bundled browser/Chromium** — PDF charts use matplotlib; the dashboard uses Plotly
  inside your own browser.
- **User‑space only** — Python + the `.venv` live in your profile; no admin, no registry.
- **Loopback only** — the server binds to `127.0.0.1`; nothing is exposed to the network.

See **[`docs/INSTALL.md`](docs/INSTALL.md)** for the full copy‑paste Windows setup, proxy
tips, and troubleshooting.

---

## 🏎️ Performance

- Target: **500k+ rows, 100+ columns.**
- DuckDB columnar aggregation + cached cleaning keep reports responsive.
- Large files: the cleaned "fact" table is built once per upload and reused across reports.

---

## 📁 Project Structure

```
avs-analytics/
├── Home.py                     # Streamlit entry point (run this)
├── requirements.txt
├── app/
│   ├── main.py                 # navigation + sidebar assembly
│   ├── config.py               # palette, paths, scope & date-preset constants
│   ├── core/                   # schema, loader, cleaning, rollup, mapping,
│   │                           #   metrics, analytics, insights, exporter
│   ├── ui/                     # theme, charts (Plotly), pdf_charts (matplotlib), components
│   └── views/                  # the 13 report pages
├── sample_data/avs_raw_data.csv
├── tests/                      # core + app smoke tests
└── docs/                       # INSTALL (Windows setup), ARCHITECTURE, screenshots
```

---

## 🆘 Troubleshooting

- **`python` is not recognized** → Python isn't on PATH. Re‑run the installer and tick
  **“Add python.exe to PATH”**, then open a new Command Prompt.
- **`python` opens the Microsoft Store** → install from
  [python.org](https://www.python.org/downloads/windows/) instead, then reopen the terminal.
- **"Connection refused" / the tab shows `https://…`** → your browser force‑upgraded the
  address to HTTPS, which a local app cannot serve. Open **`http://127.0.0.1:8501`**
  (with `http://` and the `127.0.0.1` IP) — a bare IP is never upgraded or HSTS‑pinned.
- **Browser didn't open** → open **http://127.0.0.1:8501** manually.
- **First run looks slow** → on a corporate laptop, antivirus may scan every package during
  the one‑time `pip install`; give it a few minutes.
- **`pip install` fails behind a proxy** → set the proxy, then re‑run the install command:
  `set HTTPS_PROXY=http://your-proxy:port` (ask IT for the address).
- **Port 8501 already in use** → `.venv\Scripts\python.exe -m streamlit run Home.py --server.port 8600`
  then open `http://127.0.0.1:8600`.
- **Required fields unmapped after upload** → open **Column Mapping** and map the fields marked •.
- **An upload failed** → the red panel on **Data & Upload** names the stage, the likely
  cause and the exact line; open **🐞 Full traceback** and paste that into the bug report.

---

## 📜 License & Notes

Internal analytics tool. Bundled third‑party libraries retain their respective licenses.
No data is collected or transmitted by this application.
