"""The standard dashboard, rendered once per migration category.

EOS Migration (combined, Gen-1, Gen-2), All AVS Migrations and AVS → Azure
Native all follow the same structure, so they share this module and differ only
in which population they select:

  1. **Executive Summary** — new engagements, migrations completed, hosts
     migrated, on-track accounts, ACR claimed.
  2. **Trends** — nomination count, ACR claimed, hosts and completions month over
     month, each table ending in a Cumulative column.
  3. **Current Pipeline** — nominations by state (On-Track / Completed only),
     on-track accounts by stage.
  4. **Detailed Data** — every record behind the numbers, groupable and exportable.

Every chart is selectable: clicking a month, bar or slice opens the records that
produced it.
"""
from __future__ import annotations

import pandas as pd
import streamlit as st

from app import state
from app.config import FY_START_MONTH
from app.core import glossary, kpi, metrics, segments
from app.core.metrics import fmt_currency, fmt_int
from app.ui import charts, components, drilldown
from app.ui.theme import banner, page_header, section, subheading

THIS_FY = "This FY"
ALL_TIME = "All time"

# The AVS → Azure Native motion moves *cores* to Azure-native services; the AVS
# categories move *hosts*.  Both are the Total Cores column — only the noun differs.
def _unit(category: str) -> tuple[str, str]:
    if category == segments.CAT_AVS_NATIVE:
        return "Cores Migrated", "Cores"
    return "Hosts Migrated", "Hosts"


_DESCRIPTIONS = {
    segments.CAT_EOS_ALL:
        "Every EOS Migration account combined — Gen-1, Gen-2 and any account in "
        "scope by migration path with no generation tag (those are listed under "
        "Data → Data Inconsistency).",
    segments.CAT_EOS_GEN1:
        "Accounts with an \"AVS Migration - Gen1\" tag on any wave — one tagged wave "
        "brings the whole account in.",
    segments.CAT_EOS_GEN2:
        "Accounts with an \"AVS Migration - Gen2\" tag on any wave — one tagged wave "
        "brings the whole account in.",
    segments.CAT_ALL_AVS:
        "Every migration whose target platform is AVS — on-premises, VMG, AWS/VMC, "
        "AVS-to-AVS and EOS refreshes alike.",
    segments.CAT_AVS_NATIVE:
        "Migrations away from AVS to Azure-native services (the '(From AVS)' offerings).",
}


def render(category: str) -> None:
    ctx = state.ensure_context()
    label = segments.CATEGORY_LABELS[category]
    page_header(label, _DESCRIPTIONS.get(category, ""),
                help=glossary.CATEGORY_HELP.get(category))
    components.data_quality_banner(ctx)

    fact = segments.population(ctx.fact, category)
    key = f"cat_{category}"

    # Reporting window: the global one unless this report overrides it.
    top = st.columns([2, 3])
    with top[0]:
        start, end, shown, preset = components.report_date_range(ctx, key)
    with top[1]:
        _population_note(ctx, category, fact)

    if fact.empty:
        components.empty_state(f"No nominations fall into **{label}**.")
        _why_empty(ctx, category)
        return

    # One wave sort for the whole page: every metric below reuses it.
    waves = kpi.wave_index(fact)
    unit_label, unit_short = _unit(category)
    _executive_summary(ctx, fact, waves, start, end, key, unit_label, category,
                       shown, preset)
    _trends(fact, waves, start, end, key, unit_label, unit_short, shown, preset)
    _pipeline(fact, waves, key)
    _detailed_data(fact, waves, start, end, key, shown)


# --------------------------------------------------------------------------- #
def _population_note(ctx, category: str, fact: pd.DataFrame) -> None:
    tpids = fmt_int(segments.tpid_key(fact).nunique()) if not fact.empty else "0"
    bits = [f"<b>{tpids}</b> TPIDs · <b>{fmt_int(len(fact))}</b> nomination waves"]
    if category in (segments.CAT_EOS_ALL, segments.CAT_EOS_GEN1, segments.CAT_EOS_GEN2):
        bits.append("scope from the <b>AVS Migration - Gen1/Gen2</b> tag on any wave, "
                    "or the <b>AV36/AV36P/AV52 - EOS</b> path when untagged")
    if category == segments.CAT_EOS_ALL and not fact.empty:
        split = (fact.drop_duplicates("tpid_key")["generation"]
                 .value_counts().rename({segments.GEN_UNCLASSIFIED: "no generation tag"}))
        bits.append(" · ".join(f"<b>{fmt_int(v)}</b> {k}" for k, v in split.items()))
    banner(" · ".join(bits))


def _why_empty(ctx, category: str) -> None:
    """Show what the file actually contains when a category selects nothing."""
    st.markdown("**Why is this empty?**")
    fact = ctx.fact
    accounts = fact.drop_duplicates("tpid_key")
    gen = (accounts["generation"].value_counts(dropna=False)
           .rename_axis("Generation").reset_index(name="Accounts (TPID)"))
    eos = int(accounts["is_eos_population"].sum())
    st.caption(f"This file has **{len(accounts)}** accounts, of which **{eos}** are EOS "
               f"Migration accounts — an **AVS Migration - Gen1/Gen2** tag on any wave, "
               f"or failing that an **AV36/AV36P/AV52 - EOS** migration path:")
    components.show_table(gen)
    tags = (fact["tags"].astype("string").fillna("(blank)").value_counts().head(8)
            .rename_axis("Tags").reset_index(name="Rows"))
    st.caption("Most common Tags values in the file:")
    components.show_table(tags)
    st.caption("If Tags is blank or unmapped, open **Column Mapping** and point the "
               "Tags field at the right column, then come back.")


def _executive_summary(ctx, fact: pd.DataFrame, waves: kpi.WaveIndex, start, end,
                       key: str, unit_label: str, category: str,
                       shown: str, preset: str) -> None:
    """Headline tiles for the selected period, over a This-FY row when they differ.

    Selecting "This Month" answers "how did this month go?" but loses the year it
    sits in, so anything other than This FY gets the fiscal year above it for
    context.  The two rows are computed independently — each from its own window,
    with its own records — never one derived from the other.
    """
    fy_start, fy_end = _this_fy(ctx)
    show_fy_row = preset != THIS_FY and fy_start is not None

    section("Executive summary", help=glossary.EXECUTIVE_SUMMARY,
            period=None if show_fy_row else shown)
    if show_fy_row:
        st.caption("Two periods: the fiscal year you are in, then the period you "
                   "selected. Each row is measured over its own window.")
        _summary_row(fact, waves, fy_start, fy_end, f"{key}_fy", unit_label, category,
                     _fy_label(ctx))
    _summary_row(fact, waves, start, end, key, unit_label, category, shown)


def _summary_row(fact: pd.DataFrame, waves: kpi.WaveIndex, start, end, key: str,
                 unit_label: str, category: str, period_label: str) -> None:
    """One period's tiles, with the records behind them."""
    subheading(period_label)
    engagements = kpi.new_engagements(fact, start, end, firsts=waves.first)
    completed = kpi.migrations_completed(fact, start, end, lasts=waves.last)
    hosts = kpi.hosts_migrated(fact, start, end)
    on_track = kpi.on_track_accounts(fact, lasts=waves.last)
    acr = kpi.acr_claimed(fact, start, end)

    cores_help = (glossary.CORES_MIGRATED if category == segments.CAT_AVS_NATIVE
                  else glossary.HOSTS_MIGRATED)
    components.kpi_row([
        {"label": "New Engagements", "value": fmt_int(engagements.value),
         "sub": "unique TPIDs, Wave-1 approval", "help": glossary.NEW_ENGAGEMENTS},
        {"label": "Migrations Completed", "value": fmt_int(completed.value),
         "sub": "latest wave completed", "tone": "good",
         "help": glossary.MIGRATIONS_COMPLETED},
        {"label": unit_label, "value": fmt_int(hosts.value),
         "sub": "sum of Total Cores", "help": cores_help},
        {"label": "On-Track Accounts", "value": fmt_int(on_track.value), "tone": "warn",
         "sub": "current — not period-bound", "help": glossary.ON_TRACK_ACCOUNTS},
        {"label": "ACR Claimed", "value": fmt_currency(acr.value),
         "sub": "waves ended in the period", "help": glossary.ACR_CLAIMED},
    ])
    with st.expander(f"🔎 Records behind these tiles — {period_label}"):
        panels = [
            ("New Engagements", engagements, "new-engagements"),
            ("Migrations Completed", completed, "migrations-completed"),
            (unit_label, hosts, "hosts-migrated"),
            ("On-Track Accounts", on_track, "on-track"),
            ("ACR Claimed", acr, "acr-claimed"),
        ]
        for tab, (title, metric, name) in zip(st.tabs([p[0] for p in panels]), panels):
            with tab:
                frame = kpi.drilldown_frame(metric.records)
                if frame.empty:
                    st.info(f"No records behind **{title}** for this period.")
                    continue
                components.show_table(frame, height=320)
                st.download_button("⬇️ Export to CSV",
                                   frame.to_csv(index=False).encode("utf-8"),
                                   file_name=f"{key}-{name}.csv", mime="text/csv",
                                   key=f"{key}_{name}_csv")


def _this_fy(ctx):
    """The fiscal year the reporting as-of date sits in."""
    rng = metrics.date_preset_range(ctx.as_of, THIS_FY, FY_START_MONTH)
    return (rng[0].date(), rng[1].date()) if rng else (None, None)


def _fy_label(ctx) -> str:
    fy_start, fy_end = _this_fy(ctx)
    if fy_start is None:
        return THIS_FY
    return (f"This FY ({metrics.fiscal_year_label(fy_start, FY_START_MONTH)}) — "
            f"{fy_start:%d %b %Y} → {fy_end:%d %b %Y}")


def _trends(fact: pd.DataFrame, waves: kpi.WaveIndex, start, end, key: str,
            unit_label: str, unit_short: str, shown: str, preset: str) -> None:
    by_fy = preset == ALL_TIME
    section("Trends — month over month", help=glossary.TRENDS, period=shown)
    if by_fy:
        st.caption("**All time** — each fiscal year is its own line over a shared "
                   "Jul → Jun axis, so the years can be read against each other. "
                   "Click a point **or a table row** to open that month's records.")
    else:
        st.caption("Click a bar **or a row of the table** to open the records behind "
                   "that month.")
    basis = st.radio(
        "Trend basis (nomination count only)",
        ["Nomination approval date", "Nomination created date"],
        horizontal=True, key=f"{key}_basis",
        help="Which Wave-1 date places a TPID in a month. The other three trends "
             "are dated by Actual End Date, which is what they measure.")
    date_col = "approval_date" if basis.startswith("Nomination approval") else "created_date"

    noms, nom_rows = kpi.monthly_unique_tpids(fact, date_col, start, end, firsts=waves.first)
    acr, acr_rows = kpi.monthly_acr_claimed(fact, start, end)
    hosts, host_rows = kpi.monthly_hosts(fact, start, end)
    done, done_rows = kpi.monthly_migrations_completed(fact, start, end, lasts=waves.last)

    trends = [
        ("Nomination count (unique TPIDs)", noms, nom_rows, "Nominations", date_col,
         None, False, "nominations", glossary.TREND_NOMINATIONS),
        ("ACR claimed", acr, acr_rows, "ACR Claimed", "actual_end_date",
         "total_acr", True, "claiming waves", glossary.TREND_ACR),
        (f"{unit_label} (Total Cores)", hosts, host_rows, "Hosts", "actual_end_date",
         "total_cores", False, "wave records", glossary.TREND_HOSTS),
        ("Migrations completed (unique TPIDs)", done, done_rows, "Migrations Completed",
         "actual_end_date", None, False, "completed migrations", glossary.TREND_COMPLETED),
    ]
    for title, table, rows, value_col, row_date, unit_col, currency, what, help_text in trends:
        display_col = unit_short if value_col == "Hosts" else value_col
        subheading(title, help=help_text, period=shown)
        if table.empty:
            components.empty_state(f"No {what} in the selected period.")
            continue
        if by_fy:
            _fy_trend(table, rows, value_col, display_col, row_date, unit_col, currency,
                      what, key)
        else:
            fig = charts.trend_chart(table, "period", value_col, "Cumulative",
                                     currency=currency, height=320)
            drilldown.chart_with_drilldown(
                fig, _with_period(rows, row_date), "period",
                key=f"{key}_{value_col}".replace(" ", "_"), what=what, unit_col=unit_col,
                summary=_display_trend(table, display_col, currency),
                summary_bucket="Month")
        st.write("")


def _fy_trend(table: pd.DataFrame, rows: pd.DataFrame, value_col: str, display_col: str,
              row_date: str, unit_col: str | None, currency: bool, what: str,
              key: str) -> None:
    """One line per fiscal year, with the same click-through to the records.

    A month label alone is ambiguous here — every year has a September — so the
    chart, the summary table and the records are all keyed on "FY27 Sep", and
    the line a point sits on is what tells the two Septembers apart.  The
    year-over-year grid lives in the underlying-data panel, where it can be read
    side by side without breaking that key.
    """
    split = kpi.split_by_fiscal_year(table, value_col, FY_START_MONTH)
    if split.empty:
        components.empty_state(f"No {what} to chart.")
        return
    years = sorted(split["fy"].unique())
    order = metrics.fiscal_month_order(FY_START_MONTH)

    fig = charts.fy_lines(split, "fy_month", "fy", value_col, order,
                          currency=currency, height=340)
    summary = split.rename(columns={"bucket": "Period", "fy": "FY", "fy_month": "Month",
                                    value_col: display_col})
    summary = summary[["Period", "FY", "Month", display_col]]
    if currency:
        summary[display_col] = summary[display_col].map(fmt_currency)
    drilldown.chart_with_drilldown(
        fig, kpi.label_fiscal_year(rows, row_date, FY_START_MONTH), "bucket",
        key=f"{key}_{value_col}_fy".replace(" ", "_"), what=what, unit_col=unit_col,
        summary=summary, summary_bucket="Period", curve_labels=years)

    grid = split.pivot_table(index="fy_month", columns="fy", values=value_col,
                             aggfunc="sum")
    grid = grid.reindex([m for m in order if m in grid.index]).fillna(0)
    totals = split.groupby("fy")[value_col].sum()
    st.caption("Totals per fiscal year: " + " · ".join(
        f"**{fy}** {fmt_currency(v) if currency else fmt_int(v)}"
        for fy, v in totals.items()) +
        " — no cumulative column here, because a running total across unrelated "
        "fiscal years would not mean anything.")
    display = grid.copy()
    if currency:
        for col in display.columns:
            display[col] = display[col].map(fmt_currency)
    drilldown.data_expander(
        display.reset_index().rename(columns={"fy_month": "Month"}),
        f"{key}_{value_col}_fy_grid".replace(" ", "_"),
        label="Underlying data — fiscal years side by side",
        caption="The same numbers as the chart, one column per fiscal year.")


def _pipeline(fact: pd.DataFrame, waves: kpi.WaveIndex, key: str) -> None:
    # Deliberately not given the reporting period: this section answers "where
    # does the pipeline stand right now", which no date window should narrow.
    section("Current pipeline", help=glossary.PIPELINE,
            period="Current state — not filtered by the reporting period")
    st.caption("Every account in this category at its latest wave, whatever its "
               "nomination date. Click a slice, bar or table row to open the "
               "accounts behind it.")
    states, state_rows = kpi.by_state(fact, lasts=waves.last)
    stages, stage_rows = kpi.on_track_by_stage(fact, lasts=waves.last)

    subheading("Nominations by state", help=glossary.BY_STATE,
               period="Current state — not filtered by the reporting period")
    if states.empty:
        components.empty_state("No On-Track or Completed accounts to report.")
    else:
        fig = charts.donut(states, "category", "count", height=320)
        drilldown.chart_with_drilldown(
            fig, state_rows.assign(bucket=state_rows["state"]), "bucket",
            key=f"{key}_state", what="accounts",
            summary=states.rename(columns={"category": "State", "count": "Accounts",
                                           "acr": "ACR"}),
            summary_bucket="State")

    subheading("On-track nominations by stage", help=glossary.BY_STAGE,
               period="All On-Track accounts — not filtered by the reporting period")
    if stages.empty:
        components.empty_state("No on-track accounts to report.")
    else:
        fig = charts.bar(stages, "category", "count", horizontal=True, height=320)
        drilldown.chart_with_drilldown(
            fig, stage_rows.assign(bucket=stage_rows["stage"]), "bucket",
            key=f"{key}_stage", what="accounts",
            summary=stages.rename(columns={"category": "Stage", "count": "Accounts",
                                           "acr": "ACR"}),
            summary_bucket="Stage")


def _detailed_data(fact: pd.DataFrame, waves: kpi.WaveIndex, start, end, key: str,
                   shown: str) -> None:
    section("Detailed data", help=glossary.DETAILED_DATA, period=shown)
    st.caption("Every record in this category, inheriting the filters and reporting "
               "period above. Group it, read the subtotals, then export.")
    c1, c2 = st.columns([2, 2])
    grain = c1.radio("Grain", ["Accounts (unique TPID)", "Nomination waves"],
                     horizontal=True, key=f"{key}_grain",
                     help="Unique-TPID metrics never show a TPID twice; switch to "
                          "wave level to see the underlying source records.")
    limit = c2.checkbox("Limit to the reporting period", value=start is not None,
                        key=f"{key}_limit", disabled=start is None,
                        help="Keeps only records approved inside the selected window.")
    rows = waves.last if grain.startswith("Accounts") else fact
    if limit and start is not None:
        rows = rows[kpi.in_window(rows["approval_date"], start, end)]
        if rows.empty:
            components.empty_state(
                "No records were approved inside the reporting period. Widen the "
                "period above, or untick **Limit to the reporting period**.")
            return
    drilldown.pivot_explorer(rows, key=f"{key}_pivot")
    frame = kpi.drilldown_frame(rows)
    components.show_table(frame, height=420)
    st.download_button("⬇️ Export to CSV", frame.to_csv(index=False).encode("utf-8"),
                       file_name=f"{key}-detail.csv", mime="text/csv",
                       key=f"{key}_detail_csv")


# --------------------------------------------------------------------------- #
def _with_period(rows: pd.DataFrame, date_col: str) -> pd.DataFrame:
    """Attach the chart's period label to the underlying rows for drill-down."""
    if rows is None or rows.empty:
        return pd.DataFrame()
    out = rows.copy()
    if "month" in out.columns:
        out["period"] = pd.to_datetime(out["month"].astype(str), errors="coerce") \
            .dt.to_period("M").astype(str)
    elif date_col in out.columns:
        out["period"] = pd.to_datetime(out[date_col], errors="coerce") \
            .dt.to_period("M").astype(str)
    return out


def _display_trend(table: pd.DataFrame, display_col: str | None = None,
                   currency: bool = False) -> pd.DataFrame:
    """Month, value and the Cumulative column — cumulative always last.

    Money is shown as $1.2M / $840.0K rather than a raw number.
    """
    out = table.drop(columns=["month"]).rename(columns={"period": "Month"})
    value_cols = [c for c in out.columns if c not in ("Month", "Cumulative")]
    out = out[["Month", *value_cols, "Cumulative"]]
    if currency:
        for col in [*value_cols, "Cumulative"]:
            out[col] = out[col].map(fmt_currency)
    if display_col and value_cols and display_col != value_cols[0]:
        out = out.rename(columns={value_cols[0]: display_col})
    return out


# --------------------------------------------------------------------------- #
# Page entry points (st.Page needs a distinct callable per page)
# --------------------------------------------------------------------------- #
def eos_all() -> None:
    render(segments.CAT_EOS_ALL)


def eos_gen1() -> None:
    render(segments.CAT_EOS_GEN1)


def eos_gen2() -> None:
    render(segments.CAT_EOS_GEN2)


def all_avs() -> None:
    render(segments.CAT_ALL_AVS)


def avs_native() -> None:
    render(segments.CAT_AVS_NATIVE)
