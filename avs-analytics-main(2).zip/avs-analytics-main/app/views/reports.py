"""Reports & Export — build the management PDF and the CSV extracts."""
from __future__ import annotations

from datetime import datetime

import streamlit as st

from app import state
from app.core import analytics, exporter, html_report, segments
from app.core.metrics import fmt_int
from app.ui import components
from app.ui.theme import page_header, section, subheading


def render() -> None:
    ctx = state.ensure_context()
    table = state.active_table()
    analytics.use_table(table)
    unit = state.unit_label().title()
    page_header("Reports & Export",
                "One management report, in two formats: a PDF to print or file, "
                "and a single interactive HTML file to email. **The two carry "
                "the same sections in the same order** — the same metrics, "
                "trends, matrices and accounts, from the same code. Everything "
                "renders locally.",
                help="The cover and contents are always included. Sidebar filters "
                     "and the reporting period below both apply to the report's "
                     "contents.")
    components.data_quality_banner(ctx)

    # Each report selects its own migration category, so the sidebar exposes
    # region only — scope is never something the reader has to set by hand.
    date_filter = components.page_date_filter(ctx, "rep", "created_date", table=table)
    filters, where = components.filter_sidebar(
        ctx, ["region_geo"], table=table, date_filter=date_filter)
    # The same filters without the period: the programme matrix spans the whole
    # programme whatever window the rest of the report is cut to.
    all_time_where = analytics.build_where(
        {k: v for k, v in filters.items() if k != "_date"})
    scope_label = "Filtered view" if where else "All data"
    n = analytics.total_rows(ctx.con, where)
    window = ((date_filter["start"], date_filter["end"]) if date_filter else (None, None))
    period_label = (f"{window[0]:%d %b %Y} → {window[1]:%d %b %Y}"
                    if window[0] else "All dates in the dataset")

    # ---------------------------------------------------------------- reports
    section("1 · Reports to include",
            help="Each report mirrors its Status Report page — the same "
                 "population, the same metrics, computed by the same code.")
    cols = st.columns(3)
    selected: list[str] = []
    for col, spec in zip(cols, exporter.REPORTS):
        with col:
            if st.checkbox(spec.title, value=True, key=f"rep_r_{spec.key}"):
                selected.append(spec.key)
            st.caption(spec.source)

    subheading("Supporting detail (PDF)")
    d1, d2 = st.columns([2, 3])
    with d1:
        drilldown = st.checkbox(
            "Include drill-down sections", value=True, key="rep_drill",
            help="Part 2 of the PDF: the regional matrix, the pipeline counts "
                 "and the account records behind each report, on landscape "
                 "pages — what a printed report cannot click through to. Each "
                 "report links to its drill-down and back. Every trend's own "
                 "monthly numbers are printed under its chart either way.")
    with d2:
        max_rows = st.slider(
            "Account rows per drill-down", 50, 1000, exporter.MAX_DRILLDOWN_ROWS, 50,
            key="rep_rows", disabled=not drilldown,
            help="Accounts are listed largest-ACR first within each region. Beyond "
                 "this many the table is truncated with a note — export the full "
                 "set as CSV below.")

    subheading("Optional sections",
               help="Two sections not every audience wants in the document. "
                    "Whether a section is *visible* when the HTML report opens "
                    "is the reader's own choice — each one carries its own "
                    "checkbox in the file.")
    s1, s2 = st.columns(2)
    include_blocked = s1.checkbox(
        f"{exporter.BLOCKED_TITLE} section", value=True, key="rep_blocked",
        help="Accounts stopped on a blocking Current State, with the ACR they "
             "hold up and the Status Summary explaining each one. Reported "
             "apart from every other metric.")
    include_insights = s2.checkbox(
        "Insights section", value=False, key="rep_insights",
        help="The deterministic findings — pipeline exposure, bottlenecks, "
             "delays, wave and regional patterns — written out per report.")
    sections = exporter.ReportSections(blocked=include_blocked,
                                       insights=include_insights)

    subheading("Appendix")
    appendices: list[str] = []
    for key, label in exporter.APPENDIX_LIBRARY:
        if st.checkbox(label, value=False, key=f"rep_a_{key}"):
            appendices.append(key)

    # ------------------------------------------------------------ cover text
    section("2 · Cover")
    c1, c2 = st.columns(2)
    title = c1.text_input("Report title", value=exporter.DEFAULT_TITLE,
                          key="rep_title")
    subtitle = c2.text_input("Subtitle", value=exporter.DEFAULT_SUBTITLE,
                             key="rep_subtitle")
    st.caption("The report is about the programme, not about this application: "
               "neither the app nor the file the data came from is named "
               "anywhere in the generated PDF or HTML.")

    # -------------------------------------------------------------- generate
    section("3 · Generate")
    extras = ", ".join(name for name, on in
                       ((exporter.BLOCKED_TITLE.lower(), include_blocked),
                        ("insights", include_insights)) if on) or "none"
    st.caption(f"**{scope_label}** · **{fmt_int(n)}** {unit.lower()} · period "
               f"**{period_label}** · as-of {ctx.as_of:%d %b %Y} · "
               f"{len(selected)} report(s)"
               f"{' + drill-down' if drilldown and selected else ''} · "
               f"optional sections: {extras}.")
    st.caption("Every figure is counted per account, read across all of its "
               "waves, exactly as the Status Report pages count it — the "
               "sidebar's counting mode does not change the report. Each report "
               "closes with a **Methodology & logic** section stating every rule "
               "it applied.")
    if ctx.has_tracker:
        st.caption(f"The **manual EOS tracking sheet** ({ctx.tracker_filename}) is "
                   f"loaded, so the EOS generations and the programme matrix's "
                   f"start and end dates come from it wherever it covers an "
                   f"account. Both formats read it the same way.")
    ready = bool(selected or appendices)
    if not ready:
        st.info("Tick at least one report above.")
    kw = dict(title=title or exporter.DEFAULT_TITLE, subtitle=subtitle,
              period_label=period_label, date_window=window,
              appendices=appendices, sections=sections,
              # ACR Pipeline and Nodes Deployment Planned are read over the
              # whole dataset; the period is dropped for them (and for the EOS
              # matrix), while every other filter still binds.
              all_time_where=all_time_where)
    stamp = f"{datetime.now():%Y%m%d_%H%M}"

    pdf_col, html_col = st.columns(2)
    with pdf_col:
        subheading("PDF", help="The printable record — fixed layout, page "
                               "numbers, bookmarks and internal links. The same "
                               "sections as the HTML report, plus the account "
                               "records a printed page cannot open on demand.")
        st.caption("Best for filing, printing and formal circulation.")
        if st.button("📄 Generate PDF", type="primary", width="stretch",
                     disabled=not ready):
            with st.spinner("Rendering PDF…"):
                st.session_state["_rep_pdf"] = exporter.build_report(
                    ctx, where, scope_label, selected, drilldown=drilldown,
                    max_drilldown_rows=max_rows, **kw)
                st.session_state["_rep_name"] = f"AVS_Report_{stamp}.pdf"
            st.success("PDF ready — download below.")
        if st.session_state.get("_rep_pdf"):
            st.download_button(
                "⬇️ Download PDF", st.session_state["_rep_pdf"],
                file_name=st.session_state.get("_rep_name", "report.pdf"),
                mime="application/pdf", width="stretch")

    with html_col:
        subheading("Interactive HTML",
                   help="The dashboard itself as one file — charts you can hover, "
                        "zoom and filter, drill-downs as accordions, tables you "
                        "can sort and search.")
        st.caption("Best for emailing. **One self-contained file** — charts, "
                   "styles and data are all inside it, so it opens with no "
                   "network and nothing to install.")
        if st.button("🌐 Generate HTML", type="primary", width="stretch",
                     disabled=not ready):
            with st.spinner("Rendering interactive report…"):
                st.session_state["_rep_html"] = html_report.build_html_report(
                    ctx, where, scope_label, selected, **kw)
                st.session_state["_rep_html_name"] = f"AVS_Report_{stamp}.html"
            st.success("HTML ready — download below.")
        if st.session_state.get("_rep_html"):
            size_mb = len(st.session_state["_rep_html"]) / 1e6
            st.download_button(
                "⬇️ Download HTML", st.session_state["_rep_html"],
                file_name=st.session_state.get("_rep_html_name", "report.html"),
                mime="text/html", width="stretch")
            st.caption(f"**{size_mb:.1f} MB** — most of it the charting library, "
                       "which has to travel with the file for it to work offline.")

    # ------------------------------------------------------------ data export
    section("4 · Data exports (CSV)")
    st.caption("The same filters and reporting period, as data.")
    frame = analytics.select_all(ctx.con, where)
    e1, e2, e3 = st.columns(3)
    with e1:
        st.download_button("⬇️ Cleaned data (current view)",
                           frame.to_csv(index=False).encode("utf-8"),
                           file_name="avs_clean_data.csv", mime="text/csv",
                           width="stretch")
    with e2:
        from app.core import insights as insights_mod
        ins = insights_mod.generate_insights(frame)
        st.download_button("⬇️ Insights",
                           insights_mod.insights_to_frame(ins).to_csv(index=False).encode("utf-8"),
                           file_name="avs_insights.csv", mime="text/csv", width="stretch")
    with e3:
        issues = segments.eos_consistency(ctx.fact)
        combined = "\n".join(f"# {k}\n{v.to_csv(index=False)}" for k, v in issues.items())
        st.download_button("⬇️ Data inconsistencies", combined.encode("utf-8"),
                           file_name="avs_inconsistencies.csv", mime="text/csv",
                           width="stretch")
